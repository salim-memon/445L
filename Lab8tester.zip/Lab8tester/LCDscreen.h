#include <stdint.h>
#include <stdio.h>
#include "ST7735.h"




void Snakes(void);
void DisplayMenu(void);
void ButtonPress(void);

