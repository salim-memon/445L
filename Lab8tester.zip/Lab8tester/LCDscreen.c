
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Timer0A.h"
#include "tm4c123gh6pm.h"
#include "PLL.h"
#include "Switch.h"
#include "SysTick.h"
#include "speaker.h"
#include "ST7735.h"
#include "Switch.h"


void DisplayMenu(void);

int x = 64;
int y = 64;
int dx = 0;
int dy = 0;

void ButtonPress(void){
			DisplayMenu();
					
	//if((GPIO_PORTE_DATA_R&0x01)==0x01){
		//InMenu ^= 1;
}
	
void Snakes(void){
	ST7735_Circle(52,98,3,ST7735_RED);
	ST7735_Circle(96,100,3,ST7735_RED);
	ST7735_Circle(36,81,3,ST7735_RED);
	while(1){
		volatile int delay;
		for(delay = 0; delay < 500000 ; ++delay){}
		ST7735_Circle(x,y,10,ST7735_BLACK);
			x += dx;
			if(x < 10) x = 10;
			if(x > 117) x = 117;
			
		y += dy;
			if(y < 10 ) y = 10;
			if(y >149) y = 149;
		ST7735_Circle(x,y,2,ST7735_WHITE);
		if((GPIO_PORTE_DATA_R&0x01)==0x01 ){//up button
			dx = 0;
		  dy = -1;
		}
			if((GPIO_PORTE_DATA_R&0x02)==0x02){ //down button
				dx = 0;
				dy = 1;
			} 
				if((GPIO_PORTE_DATA_R&0x04)==0x04 ){ //left button
					dx = -1;
					dy = 0;
				}
					if((GPIO_PORTE_DATA_R&0x08)==0x08){//right button
						dx = 1;
						dy = 0;
					} 
					if((GPIO_PORTE_DATA_R&0x10)==0x10){//back to menu
						ButtonPress();
					}
					
	}
}
int InMenu = 0;

void DisplayMenu(void){
	//set up switch interrupt
	//inside interrupt handler check state game/menu
	ST7735_FillScreen(0);
	ST7735_SetCursor(9,2);
	printf("Menu");
	ST7735_SetCursor(9,6);
	printf("Play");
	ST7735_SetCursor(8,8);
	printf("Scores");
	
	while(1){
		 ST7735_Circle(50,64,3,ST7735_BLACK); //playline
	   ST7735_Circle(44,83,3,ST7735_BLACK);// Scores line
		 ST7735_Circle(50 - 6 * InMenu,64 + 19 * InMenu ,3,ST7735_RED); //playline
		
		//volatile int delay;
		//for(delay = 0; delay < 1000; ++delay){}
		while((GPIO_PORTE_DATA_R & 0x01) != 0x01){
			if((GPIO_PORTE_DATA_R & 0x02) == 0x02){
				if(InMenu == 0 ){
					ST7735_FillScreen(0);
					Snakes();
				}
				
			}
		}
		InMenu ^= 1;
	}
}





			
	



