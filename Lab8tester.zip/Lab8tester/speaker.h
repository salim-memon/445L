
#include <stdint.h>
void SpeakerToggle(uint32_t alarm_On_Off);



