#ifndef	__calibh
#define	__calibh

#include <stdint.h>

uint16_t Linear_Interpolation(uint16_t);


#endif
