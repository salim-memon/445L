#include <stdint.h>
#include "tm4c123gh6pm.h"



// *******Play*******
// Plays music
// Input: none
// Output: none
void Play(void);

// *******Pause*******
// Pauses Music
// Input: none
// Output: none
void Pause(void);

// *******Rewind*******
// Puts music back to the beginning
// Input: none
// Output: none
void Reset(void);

// *******Stop*******
// Stops music back and puts it back to the beginning
// Input: none
// Output: none
void Mode_Instrument(void);

void init_Song (void);

