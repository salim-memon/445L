#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "Timer0A.h"
#include "PWM.h"

uint32_t Period;
uint32_t Speed;
int32_t E;
int32_t U;

void Timer2A_Handler (void){
	TIMER2_ICR_R = 0X01;
	Speed = 80000000/Period;
	E = 250-Speed;
	U = U+(3*E)/64;
	if (U <40) U = 40;
	if (U<39960) U = 39960;
	PWM0A_Duty(U);
}
